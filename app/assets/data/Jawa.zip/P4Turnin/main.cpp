/*****************************************************
filename: main.cpp

Description:
given two files, execute createDelta and applyDelta
create delta will make a new file, giving instructions to
applyDelta.

Apply delta will read the file, and make a new file with the 
appropriate changes. Apply delta will be given the original file
and the delta file

Created by:
Kenneth Drew Gonzales
604667929

Last edited: 3:22 pm 5/31/16 in physics class
*****************************************************/
#include "balanced.h"
#include <iostream>
#include <fstream>
#include <string>
#include <cassert>
#include "globals.h"
using namespace std;
#include <chrono>


Tree<string> makeTree(const string& str, int);
int findL(const string& iString, const Tree<string>& oldTree, int start, const int, int&, int);
void allCopys( const string& newFile, Tree<string>& instrTree, const Tree<string>& oldTree, int begin, int end, int);

/*****************************************************
Create Delta

Creates the change file. This will give instructions to
apply delta that will create the desired, update file. 
*****************************************************/
void createDelta(istream&, istream&, ostream&);

/*****************************************************
Apply Delta

Looks at the delta file created by, createDelta
and applys the changes to an empty file.
*****************************************************/
bool applyDelta(istream& oldf, istream& deltaf, ostream& newf);


// Tests to make sure the files open and that they're not null
bool runtest(string oldname, string newname, string deltaname, string newname2){
	    ifstream oldfile(oldname);
	    if (!oldfile){
	        cerr << "Cannot open " << oldname << endl;
	        return false;
	    }
	    ifstream newfile(newname);
	    if (!newfile){
	        cerr << "Cannot open " << newname << endl;
	        return false;
	    }
	    ofstream deltafile(deltaname);
	    if (!deltafile){
	        cerr << "Cannot create " << deltaname << endl;
	        return false;
	    }
	    createDelta(oldfile, newfile, deltafile);
	    deltafile.close();

	    oldfile.clear();   // clear the end of file condition
	    oldfile.seekg(0);  // reset back to beginning of the file
	    ifstream deltafile2(deltaname);
	    if (!deltafile2){
	        cerr << "Cannot read the " << deltaname << " that was just created!" << endl;
	        return false;
	    }
	    ofstream newfile2(newname2);
	    if (!newfile2){
	        cerr << "Cannot create " << newname2 << endl;
	        return false;
	    }
	    assert(applyDelta(oldfile, deltafile2, newfile2));
	    return true;
}

// Tests to make sure the resulting files are actually the same. 
bool sprintTest(string oldtext, string newtext){
	ifstream oldf(oldtext.c_str());
	ifstream newf(newtext.c_str());
		// Put everything into the old tree
	int i = 1;
	string oldString, newString, line1, line2;
	while( getline(oldf, line1) && getline(newf, line2) ){ 
		if(line1.compare(line2) != 0)
			cout << "Line isn't equal: " << i << endl;
		
		oldString += line1;
		newString += line2;
		i++;
	}
	oldf.close();
	newf.close();
	bool ret = newString.compare(oldString) == 0;
	if(ret) cout << oldtext << " passed!\n";
	else 	cout << oldtext << " failed...\n";
	return ret;
	//return equals(newString, oldString);
}


int main(){
	// ifstream old("test1.txt");
	// ifstream del("deltaTest.txt");
	// ofstream out("resultTest.txt");
	// applyDelta(old, del, out);
	// Works with all sizes. 

	cout << "=====================================\n";
	Timer timer;
	assert(runtest("test1.txt", "test2.txt", "deltaTest.txt", "resultTest.txt"));
	assert(sprintTest("test2.txt", "resultTest.txt"));
	cout << "Test Time: " << timer.elapsed() << endl;
	cout << "=====================================\n";

	// Works with all sizes.
	timer.start();
	assert(runtest("smallmart1.txt", "smallmart2.txt", "deltaSmall.txt", "resultSmall.txt"));
	assert(sprintTest("smallmart2.txt", "resultSmall.txt" ));
	cout << "Smallmart Test: " << timer.elapsed() << endl;
	cout << "=====================================\n";

	// Works with @medium, @large
	timer.start();
	assert(runtest("greeneggs1.txt", "greeneggs2.txt", "deltaGreen.txt", "resultGreen.txt"));
	assert(sprintTest("greeneggs2.txt", "resultGreen.txt"));
	cout << "Green Eggs Test: " << timer.elapsed() << endl;
	cout << "=====================================\n";



	// Works with @large, @hella
	assert(runtest("warandpeace1.txt", "warandpeace2.txt", "deltaWar.txt", "resultWar.txt"));
	assert(sprintTest( "warandpeace2.txt", "resultWar.txt"));
	cout << "War and Peace Time: " << timer.elapsed() << endl;
	cout << "=====================================\n";


	timer.start();
	// assert(runtest("strange1.txt", "strange2.txt", "deltaStrange.txt", "resultStrange.txt"));
	// assert(sprintTest("strange2.txt", "resultStrange.txt"));
	cout << "Strange Time: " << timer.elapsed() << endl;
	cout << "=====================================\n";

	cout << "Test Success!\n";
}

void createDelta(istream& oldf, istream& newf, ostream& deltaf){
		// Put everything into the old tree
	string iString;
	string line;
	while( getline(oldf, line) )
		iString += line + "\n"; 
	iString.pop_back(); // Have to remove the endl I add at the end.


	Timer timer;

	Tree<string> tinyTree(iString, TINY);	
	Tree<string> smallTree(iString, SMALL); // Has fixed Node Size. 
	Tree<string> mediTree(	iString, MEDIUM); // Has fixed Node Size. 
	Tree<string> largeTree(	iString, LARGE); // Has fixed Node Size. 
	Tree<string> ventiTree(iString, VENTI); // Has fixed Node Size.
	Tree<string> hellaTree(	iString, HELLA); // Has fixed Node Size.


	cout << "Tiny Construction: " << timer.elapsed() << endl;

	// Fill the iString with the contents of newf
	iString.clear();
	line.clear();
	while( getline(newf, line))
		iString += line + "\n";
	iString.pop_back(); // Have to remove the endl I add at the end.

	Tree<string> tinyInstr;
	allCopys(iString, tinyInstr, tinyTree, 0, iString.size(), TINY);

	Tree<string> smallInstr;		// Doesn't have fixed Node size
	allCopys(iString, smallInstr, smallTree, 0, iString.size(), SMALL);

	Tree<string> mediInstr;			// Doesn't have fixed Node size 
	allCopys(iString, mediInstr, mediTree, 0, iString.size(), MEDIUM);

	Tree<string> largeInstr;		// Doesn't have fixed Node size
	allCopys(iString, largeInstr, largeTree, 0, iString.size(), LARGE);

	Tree<string> ventiInstr;
	allCopys(iString, ventiInstr, ventiTree, 0, iString.size(), VENTI);

	Tree<string> hellaInstr;		// Doesn't have fixed Node size
	allCopys(iString, hellaInstr, hellaTree, 0, iString.size(), HELLA);

	// Find smallest instruction Tree
	vector<int> deltaSizes;
	deltaSizes.push_back(	tinyInstr.size());
	deltaSizes.push_back(	smallInstr.size());
	deltaSizes.push_back(	mediInstr.size());
	deltaSizes.push_back(	largeInstr.size());
	deltaSizes.push_back( 	ventiInstr.size());
	deltaSizes.push_back(	hellaInstr.size());

	int minDelta = deltaSizes[0];
	int N = 0;
	for(int i = 0; i < deltaSizes.size(); i++){
		if( minDelta > deltaSizes[i] ){
			minDelta = deltaSizes[i];
			N = i;
		}
	}
	switch( N ){
		case 0:
			cout << "Tiny worked best: " << tinyInstr.size() << endl;
			tinyInstr.print(deltaf);
			return;
		case 1:
			cout << "Small worked best: " << smallInstr.size() << endl;
			smallInstr.print(deltaf);
			return;

		case 2:
			cout << "Medium worked best: " << mediInstr.size() << endl;
			mediInstr.print(deltaf);
			return;
		case 3:
			cout << "Large worked best: " << largeInstr.size() << endl;
			largeInstr.print(deltaf);
			return;

		case 4: 
			cout << "Venti worked best: " << ventiInstr.size() << endl;
			ventiInstr.print(deltaf);
			return;

		case 5:
			cout << "Hella worked best: " << hellaInstr.size() << endl;
			hellaInstr.print(deltaf);
			return;

		default:
			cout << "Couldn't pick.\n";
			return;
	}
}

/*****************************************************
makeTree

Takes a huge string and breaks it up in to StringSize
array so that looking through it will be faster. Looking
through an AVL tree will be faster than iterating through
the whole string. 
*****************************************************/
Tree<string> makeTree(const string& str, int STRING_SIZE){
	Tree<string> tree;

	int i = 0;
	for(; i < str.length() - STRING_SIZE; i+= STRING_SIZE){
		tree.insert(i, str.substr(i, STRING_SIZE));
	}


	// Add whatever characters are remaining. 
	string charseq;
	charseq.resize(STRING_SIZE);
	charseq = str.substr(i, STRING_SIZE);
	
	tree.insert(str.size()-str.size()%STRING_SIZE,charseq);

	return tree;
}

/*****************************************************
findL

iString is the whole origintal file

oldTree is the whole original file put into a AVL Tree
with StringSized Nodes.

nodeOffset is the offset in the original string,
which is also the offset value stored in each node of the
AVL tree. 

stringIndex we found a match at index new string, 
I need to keep looking at the matching blocks past stringIndex.
Need to look in the oldTree for that. 

prevCharToCopy isn't being used right now. That was from
and earlier version of the algorithm. 
*****************************************************/
int findL(const string& iString, const Tree<string>& oldTree, 
	int nodeOffset, const int stringIndex, int& prevCharToCopy, int STRING_SIZE){
	string sequ;
	int L = 0;

	// accessing the index of the prior block
	int strIndex = stringIndex-1;

	// Rest prevchartocopy incase it was passed wrong. 
	prevCharToCopy = 0;

	// CHeck before for matching charaters
	if( nodeOffset-STRING_SIZE >= 0 
		&& nodeOffset%STRING_SIZE == 0){
		string prevBlock = oldTree.get(nodeOffset-STRING_SIZE);

		while( strIndex < stringIndex && strIndex >= 0
			&& prevCharToCopy < STRING_SIZE -1
			&&
			iString.at(strIndex) == prevBlock.at(STRING_SIZE-1-prevCharToCopy) ) {
			strIndex--;
			prevCharToCopy++;
		}
	}

	// Find perfect block matches
	for(int i = stringIndex; i <= iString.size() - STRING_SIZE;nodeOffset+=STRING_SIZE, i+=(STRING_SIZE)){
		for(int j = 0; j < STRING_SIZE; j++)
			sequ.push_back(iString[j+i]);
		// is sequ == get(i+=stringsize).
		if( equals(sequ, oldTree.get(nodeOffset)) ){
			L += STRING_SIZE;
		} else {
			break;
		}
		sequ.clear();
	}

	// Find extras
	string strag = oldTree.get(nodeOffset);
	for(int i = L+stringIndex, j = 0; i < iString.size() && j < strag.size(); i++, j++){
		if( iString.at(i) == strag.at(j)){
			L++;
		} else {
			break;
		}
	}
	return L;
}

string printBlock(const int len, const int offset, const string& oldf){
	string ret;
	for(int i = offset; i < offset+len; i++){
		ret.push_back(oldf.at(i));
	}
	return ret;
}
bool getInt(istream& inf, int& n){
	    char ch;
	    if (!inf.get(ch)  ||  !isascii(ch)  ||  !isdigit(ch))
	        return false;
	    inf.unget();
	    inf >> n;
	    return true;
}

bool getCommand(istream& inf, char& cmd, int& length, int& offset){
    if (!inf.get(cmd)  ||  (cmd == '\n'  &&  !inf.get(cmd)) ){
        cmd = 'x';  // signals end of file
        return true;
    }
    char ch;
    switch (cmd){
      case 'A':
        return getInt(inf, length) && inf.get(ch) && ch == ':';
      case 'C':
        return getInt(inf, length) && inf.get(ch) && ch == ',' && getInt(inf, offset);
    }
    return false;
}
bool applyDelta(istream& oldf, istream& deltaf, ostream& newf){
	string oldFile, line;
	bool addWasLast = false;
	while( getline(oldf, line) ){ 
		oldFile += line + "\n";
	}
	// Remove the last endline character i had to add. 
	oldFile.pop_back();
	// first char will be C
	char command = 'a';
	int length = 0, offset = 0;
	while(getCommand(deltaf, command, length, offset)){
		// cout << "Command: " << command << endl;
		// cout << "Offset: " << offset << endl;
		// cout << "length: " << length << endl;
		// cout << "--------------------\n";
		if( command == 'C' ){
			newf << printBlock(length, offset, oldFile);
		} else if ( command == 'A' ){
			string adding;
			for(int i = 0; i < length; i++){
				adding += deltaf.get();
			}
			newf << adding;
		} else if ( command == 'x' ){
			return true;
		} else {
			cerr << "Apply Delta failed.\n";
			return false;
		}
	}
	return true;
}

// Helper function for the createDelta
void allCopys( const string& newFile, Tree<string>& instrTree, const Tree<string>& oldTree, int begin, int end, int STRING_SIZE){
	// write add instruction.
	cout << "x";
	if( end - begin <= 0) return;
	if( end - begin < STRING_SIZE){
		string add = newFile.substr(begin, end-begin);
		// A23: copakj
		string addInstr = "A" + to_string(add.size()) + ":" + add;
		instrTree.insert(begin, addInstr);
		return;
	}
	int maxL = 0;
	int maxLStartIndex = 0;			// index of the characters to copy in the old file
	int gonnaCopyInstead = 0;
	int offsetInNewFile = begin;
	// begin and end are indecies in the newFile
	Timer timer;
	int PATIENCE = 10000;
	if( oldTree.size() > 50000 ) PATIENCE = 25;
	// This loop finds the biggest possible block of characters it 
	// that can be copied. 
	
	// for(int i = begin; i < end && timer.elapsed() < PATIENCE; i++){
	for(int i = begin; i < end; i++){
		string sequ;
		for(int j = 0; j < STRING_SIZE && i+j< end; j++){
			sequ.push_back(newFile.at(i+j));
		}
		// Find all possible starting points.
		vector<int> allMatches = oldTree.findAll(sequ);
		// not going to worry about copying  backwards yet. 
		for(int k = 0; k < allMatches.size(); k++){
			int L = findL(newFile, oldTree, allMatches.at(k), i,gonnaCopyInstead, STRING_SIZE);
			if( L > maxL){
				maxL = L;									// value of characters forward copy
				maxLStartIndex = allMatches.at(k);        	// offsetvalue in the oldTree
				offsetInNewFile = i;						// offset in new file. 
			}
		}
		// This has been tested. Iterating through it like this greatly increases
		// delta's size. 
		if(end-begin > 50000){
			i+= (end-begin)/VENTI;
		}
	}
	// write add instruction because coulnt copy
	if( maxL < STRING_SIZE){
		string add = newFile.substr(begin, end-begin);
		// A23: copakj
		string addInstr = "A" + to_string(add.size()) + ":" + add;
		instrTree.insert(begin, addInstr);
		return;
	}
	// Hex optimization TODO:
	// just because i can copy all the way, dont' mean i should. I may have already
	// wrote that instruction. 
	if ( maxL + offsetInNewFile > end ) maxL = end - offsetInNewFile; 

	string instr = "C"  +  to_string(maxL) + "," + to_string(maxLStartIndex);
	instrTree.insert( offsetInNewFile, instr);

	assert(offsetInNewFile < end);
	assert(offsetInNewFile+maxL >= begin);

	// get left half's biggets copy
	allCopys( newFile, instrTree, oldTree, begin, offsetInNewFile, STRING_SIZE);
	// get right half's biggest copy
	allCopys( newFile , instrTree, oldTree, offsetInNewFile+maxL, end, STRING_SIZE);
}