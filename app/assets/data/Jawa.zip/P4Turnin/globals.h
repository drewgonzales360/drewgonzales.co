
#ifndef GLOBALS_H
#define GLOBALS_H
#include <chrono>

#include <string>
using namespace std;

bool equals(string rhs, string lhs);

const int TINY = 2;
const int SMALL = 6;
const int MEDIUM = 8;
const int LARGE = 16;
const int VENTI = 32;
const int HELLA = 64;

class Timer{
  public:
    Timer();
    void start();
    double elapsed() const;
  private:
    std::chrono::high_resolution_clock::time_point m_time;
};
#endif