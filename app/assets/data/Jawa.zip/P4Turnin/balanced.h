/*****************************************************
FileName: balanced.h

Description:
balanced.h holds the implementation of an AVL tree. 
I had to make an AVL tree because when I was adding 
the items as i iterated through the string, everything
kept getting pushed to one side, making a linked list. 

Created by: 
Kenneth Drew Gonzales
604667929

Last edited: 3:15 pm 5/31/16 in physics class. 
*****************************************************/  
#ifndef BALANCED_H
#define BALANCED_H
#include <iostream>
#include <string>
#include <vector>
#include "globals.h"

using namespace std;
template<typename T>
class Tree{
private:
	struct Node{
		int height;
		int offset;
		T charsequence;
		Node* left;
		Node* right;
		Node(int, T);
		~Node();
	};

	// data members for Tree. 
	Node* head;
	int treeSize;

	// The 6 functions below are for continually balancing the tree.
	int getBalFactor(Node*) const;
	void balance(Node*&);
	void leftRight(Node*&); // double left
	void rightLeft(Node*&); // double right
	void rotateRight(Node*&); 
	void rotateLeft(Node*&);
	int getHeight(Node*) const;

	// Helper functions are called by normal functions,
	// but the helpers are recursive. 
	void printHelper(Node*, ostream&) const;
	T getHelper(int offset, Tree<T>::Node* iter) const;
	Tree<T>::Node* copyHelper(const Node *toCopy) const;
	vector<int> findAllHelper(string found, Node* iter) const;
	void insertHelper(Node*& iter,const int off,const T val);
	int searchHelper(T found, Node* iter) const;

public:
	// Need to move this back to private: getHighet
	Tree();
	Tree(const string&, int);
	Tree(const Tree&);
	~Tree();
	
	// Constant functions. 	
	vector<int> findAll(string found) const;
	void printHead() const;
	void print( ostream&) const;
	Node* getHead() const { return head; };
	T get(int offset) const;
	bool search(T found, int&) const;
	int size() const { return treeSize; };
	void insert(int offset, T charsequence);
};

// This is the actual function that balances the tree
// It needs to know the 
// balance (which needs to know the heigt)
// then calls rotations to balance the tree. 
template<typename T>
void Tree<T>::balance(Node*& iter){
	int balance = getBalFactor(iter);
	if( balance >= 2 ){
		if(getBalFactor(iter->right) < 0 )
			rotateRight(iter->right);
		rotateLeft(iter);
		
	} else if ( balance <= -2 ){
		if( getBalFactor(iter->left) > 0 ) 
			rotateLeft(iter->left);
		rotateRight(iter);
	}
}

/*****************************************************
getHeight

finds its height, and updates the height of every element
beneath it in the tree. 
*****************************************************/
template<typename T>
int Tree<T>::getHeight(Node* tar) const{
	if(tar == nullptr) return -1;
	if( tar->left == nullptr && tar->right == nullptr){
		tar->height = 0;
		return 0;
	}
	int right = getHeight(tar->right) + 1;
	int left = getHeight(tar->left) + 1;
	tar->height = left > right ? left : right;

	return tar->height;
}

// if the my-right subtree has more items than the
// my-left subtree, the the tree starting at pointer my
// is said to be right heavy.
template<typename T>
int Tree<T>::getBalFactor(Node* tar) const{
	int left = getHeight(tar->left);
	int right =  getHeight(tar->right);
	return right-left;
}
/*****************************************************
The following four functions are called rotations
They move items in the BST so that the tree is balanced.
IE they create an AVL tree.
*****************************************************/
template<typename T>
void Tree<T>::leftRight(Node*& pivot){ // double left
	if( pivot->left == nullptr) return;
	Node* newLeft = pivot->left;
	Node* newCenter = newLeft->right;

	newLeft->right = newCenter->left;
	pivot->left = newCenter->right;

	newCenter->right = pivot;
	newCenter->left = newLeft;

	pivot = newCenter;
	getHeight(pivot);
}

template<typename T>
void Tree<T>::rightLeft(Node*& pivot){ // double right
	if( pivot->right == nullptr) return;
	Node* newRight = pivot->right;
	Node* newCenter = newRight->left;

	newRight->left = newCenter->right;
	pivot->right = newCenter->left;

	newCenter->left = pivot;
	newCenter->right = newRight;

	pivot = newCenter;
	getHeight(pivot);
}

template<typename T>
void Tree<T>::rotateRight(Node*& pivot){
	if( pivot->left == nullptr ) return;
	Node* left = pivot->left;
	pivot->left = left->right;
	left->right = pivot;
	pivot = left;
	getHeight(pivot);
}

template<typename T>
void Tree<T>::rotateLeft(Node*& pivot){
	if( pivot->right == nullptr ) return;
	Node* right = pivot->right;
	pivot->right = right->left;
	right->left = pivot;
	pivot = right;
	getHeight(pivot);
}

///////////////////////////////////////////////////////////
// Node constructor;
template<typename T>
Tree<T>::Node::Node(int o, T c){
	charsequence = c;
	offset = o;
	height = 0;
	left = nullptr;
	right = nullptr;
}
// Node destructor
template<typename T>
Tree<T>::Node::~Node(){
	delete left;
	delete right;
}
/*****************************************************
Big 4 // no assignment operator
*****************************************************/
// Tree COnstructor
template<typename T>
Tree<T>::Tree(){
	head = nullptr;
	treeSize = 0;
	return;
}
template<typename T>
Tree<T>::Tree(const string& str, int STRING_SIZE){
	head = nullptr;
	treeSize = 0;
	int i = 0;
	for(; i < str.length() - STRING_SIZE; i+= STRING_SIZE){
		this->insert(i, str.substr(i, STRING_SIZE));
	}


	// Add whatever characters are remaining. 
	string charseq;
	charseq.resize(STRING_SIZE);
	charseq = str.substr(i, STRING_SIZE);
	
	this->insert(str.size()-str.size()%STRING_SIZE,charseq);

	return;
}

// Tree Destructor
template<typename T>
Tree<T>::~Tree(){
	delete head;
}

// Copy Constructor 
template<typename T>
Tree<T>::Tree(const Tree<T>& copy){
	head = copyHelper(copy.head);
}

// Copy Constructor Helper
template<typename T>
typename Tree<T>::Node* Tree<T>::copyHelper(const Node *toCopy) const {
	if (toCopy == nullptr)
		return nullptr;
	Node *copyNode = new Node(toCopy->offset, toCopy->charsequence);
	copyNode->left = copyHelper(toCopy->left);
	copyNode->right = copyHelper(toCopy->right);
	return copyNode;
}

/*****************************************************
insert(offset, value)
*****************************************************/
template<typename T>
void Tree<T>::insert(int off, T val) { insertHelper(head, off, val); }

template<typename T>
void Tree<T>::insertHelper(Node*& iter, const int off, const T val){
	if( iter == nullptr){
		iter = new Node(off, val);
		treeSize ++;
		return;
	}
	if( off > iter->offset){
		insertHelper(iter->right, off, val);
	} else {
		insertHelper(iter->left, off, val);
	}
	balance(iter);
}

// Specific for strings. I need this because it will update the treeSize of 
// The tree differently. 
template<>
void Tree<string>::insertHelper(Node*& iter, const int off, const string val){
	if( iter == nullptr){
		iter = new Node(off, val);
		treeSize += val.size();
		return;
	}
	if( off > iter->offset){
		insertHelper(iter->right, off, val);
	} else {

		insertHelper(iter->left, off, val);
	}
	balance(iter);
}
/*****************************************************
print the tree

The actual print function takes no parameters,
but the helper takes the head so I can call it recursively.
*****************************************************/
template<typename T>
void Tree<T>::print( ostream& out ) const { printHelper(head, out); }
template<typename T>
void Tree<T>::printHelper(Node* start, ostream& out) const { // private
	if( start == nullptr ) return;
	printHelper(start->left, out);
	out << start->charsequence;
	printHelper(start->right, out);
	return;
}
/*****************************************************
SEARCH 
returns two values, the integer value of the offset
that was found, and a boolean telling you if the value 
was ever in the tree. If the value is not in the tree
the offset returned will be -1. 

The index returned is a random index. There is no
telling which index it will find first. 
*****************************************************/
template<typename T>
bool Tree<T>::search(T found, int& index) const { // public
	index = searchHelper(found, head);
	if(index == -1) return false;
	return true;
}

template<typename T>
int Tree<T>::searchHelper(T found, Node* iter) const { // private
	if(iter == nullptr) return -1;
	if( found == (iter->charsequence) ) return iter->offset;

	int left = searchHelper(found, iter->left);
	int right = searchHelper(found, iter->right);

	return left > -1 ? left : right;
}

// overloaded the searchHelper for strings, but it has the
// the same functionality 
template<>
int Tree<string>::searchHelper(string found, Node* iter) const { // private
	if(iter == nullptr) return -1;
	if( equals(found,iter->charsequence)) return iter->offset;

	int left = searchHelper(found, iter->left);
	int right = searchHelper(found, iter->right);
	if( left == -1)
		return right;
	else
		return left;
}

/*****************************************************
get // calls getHelper

offsets are unique. This will return the value at whatever
offset you look for. 
*****************************************************/
template<typename T>
T Tree<T>::get(int offset) const{
	return getHelper(offset, head);
}

template<typename T> 
T Tree<T>::getHelper(int offset, Tree<T>::Node* iter) const{
	if(iter == nullptr) return "";
	if( offset == iter->offset)
		return iter->charsequence;

	if( offset < iter->offset)
		return getHelper(offset, iter->left);
	else
		return getHelper(offset, iter->right);
}
/*****************************************************
FindAll // calls findAllHelper
const public
returns a vector of all the indices where a string was found
*****************************************************/

template<>
vector<int> Tree<string>::findAllHelper(string found, Node* iter) const { // private
	vector<int> ret;
	if(iter == nullptr) return ret;
	if( equals(found,iter->charsequence)){
		vector<int> ret;
		ret.push_back(iter->offset);
		return ret;
	}
	vector<int> left = findAllHelper(found, iter->left);
	vector<int> right = findAllHelper(found, iter->right);
	
	for(int i = 0; i < left.size(); i++){
		ret.push_back(left.at(i));
	}

	for(int i = 0; i < right.size();i++){
		ret.push_back(right.at(i));
	}
	return ret;
}	
template<>
vector<int> Tree<string>::findAll(string found) const { // public
	return findAllHelper(found, head);
}
#endif