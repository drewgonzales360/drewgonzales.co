vector<int> allMatches = findAll(sequ);
int maxL = 0;
int maxLStartIndex = 0;
int maxLGonnzaCopyInstead = 0;
for(int i = 0; i < allMatches.size(); i++){
	int L = findL(iString, oldTree, index, j,gonnaCopyInstead);
	if( L > maxL){
		maxL = L;
		maxLStartIndex = index;
		maxLGonnzaCopyInstead = gonnaCopyInstead;
	}
}