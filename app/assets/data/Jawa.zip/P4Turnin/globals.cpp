#include "globals.h"
#include <string>
#include <chrono>

using namespace std;
bool equals(string rhs, string lhs){
	if(rhs.length() != lhs.length()){
		return false;
	}

	return (rhs.compare(lhs) == 0);
	for(int i = 0; i < rhs.length(); i++){
		if (rhs[i] != lhs[i]){
			return false;
		}
	}
	return true;
}


Timer::Timer(){ start(); }
void Timer::start(){
	m_time = std::chrono::high_resolution_clock::now();
}
double Timer::elapsed() const{
	std::chrono::duration<double,std::milli> diff =
		std::chrono::high_resolution_clock::now() - m_time;
    return diff.count();
}
